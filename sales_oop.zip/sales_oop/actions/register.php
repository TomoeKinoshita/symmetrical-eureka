<?php

include '../classes/Sales.php';
$sales = new Sales;

$sales->register($_POST);