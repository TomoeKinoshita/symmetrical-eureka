<?php

include '../classes/Sales.php';
$sales = new Sales;

$sales->editProduct($_POST);