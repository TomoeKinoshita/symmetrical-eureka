<?php

include '../classes/Sales.php';
$sales = new Sales;

$sales->addProduct($_POST);